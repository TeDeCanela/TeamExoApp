const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../../src/app');

describe('PUT /api/notificaciones/:notificacionId/leida - Marcar notificación como leída', () => {
    let idNotificacion;

    beforeAll(async () => {
        await mongoose.connect(process.env.MONGO_URI);
        const resCrear = await request(app).post('/api/notificaciones').send({
            usuarioId: 123,
            mensaje: 'Mensaje para marcar leída',
        });
        idNotificacion = resCrear.body.notificacion.notificacionId;
    });

    afterAll(async () => {
        await mongoose.connection.db.dropDatabase();
        await mongoose.connection.close();
    });

    test('Debería actualizar el campo "leida" a true', async () => {
        const res = await request(app).put(`/api/notificaciones/${idNotificacion}/leida`).send();

        expect(res.statusCode).toBe(200);
        expect(res.body.notificacion).toBeDefined();
        expect(res.body.notificacion.leida).toBe(true);
    });
});
