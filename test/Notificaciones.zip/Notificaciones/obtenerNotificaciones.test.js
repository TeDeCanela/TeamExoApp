const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../../src/app');

describe('GET /api/notificaciones/:usuarioId - Obtener notificaciones', () => {
    const usuarioIdTest = 123;

    beforeAll(async () => {
        await mongoose.connect(process.env.MONGO_URI);
        // Crear al menos una notificación para el test
        await request(app).post('/api/notificaciones').send({
            usuarioId: usuarioIdTest,
            mensaje: 'Mensaje para obtener',
        });
    });

    afterAll(async () => {
        await mongoose.connection.db.dropDatabase();
        await mongoose.connection.close();
    });

    test('Debería devolver un array de notificaciones no leídas', async () => {
        const res = await request(app)
            .get(`/api/notificaciones/${usuarioIdTest}`)
            .query({ soloNoLeidas: 'true', limit: 5, page: 1 });

        expect(res.statusCode).toBe(200);
        expect(Array.isArray(res.body.resultados)).toBe(true);
        expect(res.body.resultados.length).toBeGreaterThan(0);
        expect(res.body.resultados[0].leida).toBe(false);
    });
});
