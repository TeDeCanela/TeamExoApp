const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../../src/app');

describe('DELETE /api/notificaciones/:notificacionId - Eliminar notificación', () => {
    let idNotificacion;

    beforeAll(async () => {
        await mongoose.connect(process.env.MONGO_URI);
        const resCrear = await request(app).post('/api/notificaciones').send({
            usuarioId: 123,
            mensaje: 'Mensaje para eliminar',
        });
        idNotificacion = resCrear.body.notificacion.notificacionId;
    });

    afterAll(async () => {
        await mongoose.connection.db.dropDatabase();
        await mongoose.connection.close();
    });

    test('Debería eliminar la notificación', async () => {
        const res = await request(app).delete(`/api/notificaciones/${idNotificacion}`).send();

        expect(res.statusCode).toBe(200);
        expect(res.body.msg).toMatch(/eliminada/i);
    });
});
