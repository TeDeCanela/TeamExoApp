const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../../src/app');
const Publicacion = require('../../src/modelos/Notificacion');

describe('POST /api/notificaciones - Crear notificación', () => {
    beforeAll(async () => {
        await mongoose.connect(process.env.MONGO_URI);
    });

    afterAll(async () => {
        await mongoose.connection.db.dropDatabase();
        await mongoose.connection.close();
    });

    test('Debería crear una nueva notificación', async () => {
        const res = await request(app)
            .post('/api/notificaciones')
            .send({
                usuarioId: 123,
                mensaje: 'Mensaje de prueba',
            });

        expect(res.statusCode).toBe(201);
        expect(res.body.notificacion).toBeDefined();
        expect(res.body.notificacion.usuarioId).toBe(123);
        expect(res.body.notificacion.mensaje).toBe('Mensaje de prueba');
        expect(res.body.notificacion.leida).toBe(false);
    });
});
